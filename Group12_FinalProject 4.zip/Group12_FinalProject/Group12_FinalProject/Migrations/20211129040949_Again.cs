﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Group12_FinalProject.Migrations
{
    public partial class Again : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "HostEmail",
                table: "Properties");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "HostEmail",
                table: "Properties",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
