﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Group12_FinalProject.Migrations
{
    public partial class Setup7 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
