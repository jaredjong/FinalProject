﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Group12_FinalProject.Migrations
{
    public partial class Setup2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PropertyReview");

            migrationBuilder.AddColumn<int>(
                name: "PropertiesPropertyID",
                table: "Reviews",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Reviews_PropertiesPropertyID",
                table: "Reviews",
                column: "PropertiesPropertyID");

            migrationBuilder.AddForeignKey(
                name: "FK_Reviews_Properties_PropertiesPropertyID",
                table: "Reviews",
                column: "PropertiesPropertyID",
                principalTable: "Properties",
                principalColumn: "PropertyID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Reviews_Properties_PropertiesPropertyID",
                table: "Reviews");

            migrationBuilder.DropIndex(
                name: "IX_Reviews_PropertiesPropertyID",
                table: "Reviews");

            migrationBuilder.DropColumn(
                name: "PropertiesPropertyID",
                table: "Reviews");

            migrationBuilder.CreateTable(
                name: "PropertyReview",
                columns: table => new
                {
                    PropertiesPropertyID = table.Column<int>(type: "int", nullable: false),
                    ReviewsReviewID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PropertyReview", x => new { x.PropertiesPropertyID, x.ReviewsReviewID });
                    table.ForeignKey(
                        name: "FK_PropertyReview_Properties_PropertiesPropertyID",
                        column: x => x.PropertiesPropertyID,
                        principalTable: "Properties",
                        principalColumn: "PropertyID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PropertyReview_Reviews_ReviewsReviewID",
                        column: x => x.ReviewsReviewID,
                        principalTable: "Reviews",
                        principalColumn: "ReviewID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_PropertyReview_ReviewsReviewID",
                table: "PropertyReview",
                column: "ReviewsReviewID");
        }
    }
}
