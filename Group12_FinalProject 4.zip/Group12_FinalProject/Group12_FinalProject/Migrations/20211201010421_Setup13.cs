﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Group12_FinalProject.Migrations
{
    public partial class Setup13 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Reservations_Properties_PropertyID",
                table: "Reservations");

            migrationBuilder.DropForeignKey(
                name: "FK_Reservations_Reservations_ReservationID1",
                table: "Reservations");

            migrationBuilder.DropIndex(
                name: "IX_Reservations_PropertyID",
                table: "Reservations");

            migrationBuilder.DropIndex(
                name: "IX_Reservations_ReservationID1",
                table: "Reservations");

            migrationBuilder.DropColumn(
                name: "Address",
                table: "Reviews");

            migrationBuilder.DropColumn(
                name: "CurrentDate",
                table: "Reservations");

            migrationBuilder.DropColumn(
                name: "Discriminator",
                table: "Reservations");

            migrationBuilder.DropColumn(
                name: "NumberofDays",
                table: "Reservations");

            migrationBuilder.DropColumn(
                name: "PropertyID",
                table: "Reservations");

            migrationBuilder.DropColumn(
                name: "ReservationDetailID",
                table: "Reservations");

            migrationBuilder.DropColumn(
                name: "ReservationEndDate",
                table: "Reservations");

            migrationBuilder.DropColumn(
                name: "ReservationID1",
                table: "Reservations");

            migrationBuilder.DropColumn(
                name: "ReservationStartDate",
                table: "Reservations");

            migrationBuilder.DropColumn(
                name: "StayPrice",
                table: "Reservations");

            migrationBuilder.CreateTable(
                name: "ReservationDetails",
                columns: table => new
                {
                    ReservationDetailID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StayPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    ReservationStartDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CurrentDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ReservationEndDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ReservationID = table.Column<int>(type: "int", nullable: true),
                    PropertyID = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ReservationDetails", x => x.ReservationDetailID);
                    table.ForeignKey(
                        name: "FK_ReservationDetails_Properties_PropertyID",
                        column: x => x.PropertyID,
                        principalTable: "Properties",
                        principalColumn: "PropertyID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ReservationDetails_Reservations_ReservationID",
                        column: x => x.ReservationID,
                        principalTable: "Reservations",
                        principalColumn: "ReservationID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ReservationDetails_PropertyID",
                table: "ReservationDetails",
                column: "PropertyID");

            migrationBuilder.CreateIndex(
                name: "IX_ReservationDetails_ReservationID",
                table: "ReservationDetails",
                column: "ReservationID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ReservationDetails");

            migrationBuilder.AddColumn<string>(
                name: "Address",
                table: "Reviews",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "CurrentDate",
                table: "Reservations",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Discriminator",
                table: "Reservations",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "NumberofDays",
                table: "Reservations",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "PropertyID",
                table: "Reservations",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ReservationDetailID",
                table: "Reservations",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "ReservationEndDate",
                table: "Reservations",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ReservationID1",
                table: "Reservations",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "ReservationStartDate",
                table: "Reservations",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "StayPrice",
                table: "Reservations",
                type: "decimal(18,2)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Reservations_PropertyID",
                table: "Reservations",
                column: "PropertyID");

            migrationBuilder.CreateIndex(
                name: "IX_Reservations_ReservationID1",
                table: "Reservations",
                column: "ReservationID1");

            migrationBuilder.AddForeignKey(
                name: "FK_Reservations_Properties_PropertyID",
                table: "Reservations",
                column: "PropertyID",
                principalTable: "Properties",
                principalColumn: "PropertyID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Reservations_Reservations_ReservationID1",
                table: "Reservations",
                column: "ReservationID1",
                principalTable: "Reservations",
                principalColumn: "ReservationID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
