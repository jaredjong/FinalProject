﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Group12_FinalProject.Migrations
{
    public partial class Setup9 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Reviews_Properties_PropertiesPropertyID",
                table: "Reviews");

            migrationBuilder.DropColumn(
                name: "WeekDayPrice",
                table: "Reservations");

            migrationBuilder.RenameColumn(
                name: "disputeStatus",
                table: "Reviews",
                newName: "DisputeStatus");

            migrationBuilder.RenameColumn(
                name: "PropertiesPropertyID",
                table: "Reviews",
                newName: "PropertyID");

            migrationBuilder.RenameIndex(
                name: "IX_Reviews_PropertiesPropertyID",
                table: "Reviews",
                newName: "IX_Reviews_PropertyID");

            migrationBuilder.RenameColumn(
                name: "WeekEndPrice",
                table: "Reservations",
                newName: "StayPrice");

            migrationBuilder.RenameColumn(
                name: "RegistrationDetailID",
                table: "Reservations",
                newName: "ReservationDetailID");

            migrationBuilder.AddColumn<DateTime>(
                name: "CurrentDate",
                table: "Reservations",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "NumberofDays",
                table: "Reservations",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "ReservationEndDate",
                table: "Reservations",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "ReservationStartDate",
                table: "Reservations",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "HostEmail",
                table: "Properties",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Reviews_Properties_PropertyID",
                table: "Reviews",
                column: "PropertyID",
                principalTable: "Properties",
                principalColumn: "PropertyID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Reviews_Properties_PropertyID",
                table: "Reviews");

            migrationBuilder.DropColumn(
                name: "CurrentDate",
                table: "Reservations");

            migrationBuilder.DropColumn(
                name: "NumberofDays",
                table: "Reservations");

            migrationBuilder.DropColumn(
                name: "ReservationEndDate",
                table: "Reservations");

            migrationBuilder.DropColumn(
                name: "ReservationStartDate",
                table: "Reservations");

            migrationBuilder.DropColumn(
                name: "HostEmail",
                table: "Properties");

            migrationBuilder.RenameColumn(
                name: "DisputeStatus",
                table: "Reviews",
                newName: "disputeStatus");

            migrationBuilder.RenameColumn(
                name: "PropertyID",
                table: "Reviews",
                newName: "PropertiesPropertyID");

            migrationBuilder.RenameIndex(
                name: "IX_Reviews_PropertyID",
                table: "Reviews",
                newName: "IX_Reviews_PropertiesPropertyID");

            migrationBuilder.RenameColumn(
                name: "StayPrice",
                table: "Reservations",
                newName: "WeekEndPrice");

            migrationBuilder.RenameColumn(
                name: "ReservationDetailID",
                table: "Reservations",
                newName: "RegistrationDetailID");

            migrationBuilder.AddColumn<decimal>(
                name: "WeekDayPrice",
                table: "Reservations",
                type: "decimal(18,2)",
                nullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Reviews_Properties_PropertiesPropertyID",
                table: "Reviews",
                column: "PropertiesPropertyID",
                principalTable: "Properties",
                principalColumn: "PropertyID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
